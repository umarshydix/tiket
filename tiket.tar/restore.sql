--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.type_transportasi DROP CONSTRAINT type_transportasi_pkey;
ALTER TABLE ONLY public.tb_transportasi DROP CONSTRAINT tb_transportasi_pkey;
ALTER TABLE ONLY public.tb_transaksi DROP CONSTRAINT tb_transaksi_pkey;
ALTER TABLE ONLY public.tb_rute DROP CONSTRAINT tb_rute_pkey;
ALTER TABLE ONLY public.tb_petugas DROP CONSTRAINT tb_petugas_pkey;
ALTER TABLE ONLY public.tb_pemasaran DROP CONSTRAINT tb_pemasaran_pkey;
ALTER TABLE ONLY public.tb_level DROP CONSTRAINT tb_level_pkey;
DROP TABLE public.type_transportasi;
DROP TABLE public.tb_transportasi;
DROP TABLE public.tb_transaksi;
DROP TABLE public.tb_rute;
DROP TABLE public.tb_petugas;
DROP TABLE public.tb_pemasaran;
DROP TABLE public.tb_level;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level character varying(4) NOT NULL,
    nama_level character varying(20)
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Name: tb_pemasaran; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_pemasaran (
    id_pemasaran character varying(4) NOT NULL,
    kode_pemasaran character varying(5),
    tanggal_pemasaran date,
    tempat_pemasaran character varying(55),
    id_pelanggan character varying(4),
    kode_kursi character varying(5),
    id_rute character varying(4),
    tujuan character varying(20),
    tanggal_berangkat date,
    jam_cekin time without time zone,
    jam_berangkat time without time zone,
    total_bayar integer,
    id_petugas character varying(4)
);


ALTER TABLE tb_pemasaran OWNER TO postgres;

--
-- Name: tb_petugas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_petugas (
    id_petugas character varying(4) NOT NULL,
    username character varying(20),
    password character varying(20),
    nama_petugas character varying(55),
    id_level character varying(4)
);


ALTER TABLE tb_petugas OWNER TO postgres;

--
-- Name: tb_rute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_rute (
    id_rute character varying(4) NOT NULL,
    tujuan character varying(20),
    rute_awal character varying(20),
    rute_akhir character varying(20),
    harga integer,
    id_transportasi character varying(4)
);


ALTER TABLE tb_rute OWNER TO postgres;

--
-- Name: tb_transaksi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_transaksi (
    id_penumpang character varying(4) NOT NULL,
    username character varying(20),
    password character varying(20),
    nama_penumpang character varying(55),
    alamat_penumpang text,
    tanggal_lahir date,
    jenis_kelamin character varying(10),
    telepon character varying(11)
);


ALTER TABLE tb_transaksi OWNER TO postgres;

--
-- Name: tb_transportasi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_transportasi (
    id_transportasi character varying(4) NOT NULL,
    kode character varying(5),
    jumlah_kursi character varying(5),
    keterangan character varying(20),
    id_type_transportasi character varying(4)
);


ALTER TABLE tb_transportasi OWNER TO postgres;

--
-- Name: type_transportasi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE type_transportasi (
    id_type_transportasi character varying(4) NOT NULL,
    nama_type character varying(20),
    keterangan character varying(10)
);


ALTER TABLE type_transportasi OWNER TO postgres;

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2834.dat';

--
-- Data for Name: tb_pemasaran; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_pemasaran (id_pemasaran, kode_pemasaran, tanggal_pemasaran, tempat_pemasaran, id_pelanggan, kode_kursi, id_rute, tujuan, tanggal_berangkat, jam_cekin, jam_berangkat, total_bayar, id_petugas) FROM stdin;
\.
COPY tb_pemasaran (id_pemasaran, kode_pemasaran, tanggal_pemasaran, tempat_pemasaran, id_pelanggan, kode_kursi, id_rute, tujuan, tanggal_berangkat, jam_cekin, jam_berangkat, total_bayar, id_petugas) FROM '$$PATH$$/2829.dat';

--
-- Data for Name: tb_petugas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_petugas (id_petugas, username, password, nama_petugas, id_level) FROM stdin;
\.
COPY tb_petugas (id_petugas, username, password, nama_petugas, id_level) FROM '$$PATH$$/2830.dat';

--
-- Data for Name: tb_rute; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_rute (id_rute, tujuan, rute_awal, rute_akhir, harga, id_transportasi) FROM stdin;
\.
COPY tb_rute (id_rute, tujuan, rute_awal, rute_akhir, harga, id_transportasi) FROM '$$PATH$$/2831.dat';

--
-- Data for Name: tb_transaksi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_transaksi (id_penumpang, username, password, nama_penumpang, alamat_penumpang, tanggal_lahir, jenis_kelamin, telepon) FROM stdin;
\.
COPY tb_transaksi (id_penumpang, username, password, nama_penumpang, alamat_penumpang, tanggal_lahir, jenis_kelamin, telepon) FROM '$$PATH$$/2828.dat';

--
-- Data for Name: tb_transportasi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_transportasi (id_transportasi, kode, jumlah_kursi, keterangan, id_type_transportasi) FROM stdin;
\.
COPY tb_transportasi (id_transportasi, kode, jumlah_kursi, keterangan, id_type_transportasi) FROM '$$PATH$$/2832.dat';

--
-- Data for Name: type_transportasi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY type_transportasi (id_type_transportasi, nama_type, keterangan) FROM stdin;
\.
COPY type_transportasi (id_type_transportasi, nama_type, keterangan) FROM '$$PATH$$/2833.dat';

--
-- Name: tb_level tb_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level
    ADD CONSTRAINT tb_level_pkey PRIMARY KEY (id_level);


--
-- Name: tb_pemasaran tb_pemasaran_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_pemasaran
    ADD CONSTRAINT tb_pemasaran_pkey PRIMARY KEY (id_pemasaran);


--
-- Name: tb_petugas tb_petugas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_petugas
    ADD CONSTRAINT tb_petugas_pkey PRIMARY KEY (id_petugas);


--
-- Name: tb_rute tb_rute_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_rute
    ADD CONSTRAINT tb_rute_pkey PRIMARY KEY (id_rute);


--
-- Name: tb_transaksi tb_transaksi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_transaksi
    ADD CONSTRAINT tb_transaksi_pkey PRIMARY KEY (id_penumpang);


--
-- Name: tb_transportasi tb_transportasi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_transportasi
    ADD CONSTRAINT tb_transportasi_pkey PRIMARY KEY (id_transportasi);


--
-- Name: type_transportasi type_transportasi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY type_transportasi
    ADD CONSTRAINT type_transportasi_pkey PRIMARY KEY (id_type_transportasi);


--
-- PostgreSQL database dump complete
--

